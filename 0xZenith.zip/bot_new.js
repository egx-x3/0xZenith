const ASCII = `
════════════════════════════
VERSIBOT : BOT-V5.0.0.0
OWNER    : EGX BOT
NAMA BOT :𝟬𝘅𝗭𝗲𝗻𝗶𝘁𝗵
NO OWNER : 6283822259027
══════𝟬𝘅𝗭𝗲𝗻𝗶𝘁𝗵-𝘯𝘦𝘸 𝘣𝘰𝘵══════
bot readyⓘ
`;

const { default: s, useMultiFileAuthState, fetchLatestBaileysVersion, makeCacheableSignalKeyStore, Browsers, downloadContentFromMessage, generateWAMessageFromContent, prepareWAMessageMedia } = require('@whiskeysockets/baileys');
const p = require('pino'); const axios = require('axios'); const fs = require('fs'); const fsp = require('fs/promises'); const path = require('path'); const { execFile } = require('child_process'); const rl = require('readline'); const cr = require('crypto');
const FormData = require('form-data');

const C = { PREFIX: '.', OWNER: ['6283822259027', '278567871062047@lid', '27475593683079@lid'], PAIRING: '6283822259027', CODE: '666XXBOT', AUTH: './auth_info', WM: 'egx code', IMG: './img' };
const lg = p({ level: 'silent' }); const U = 'https://api.kyzzz.xyz'; const K = 'kyzz592116496';

const D = './db_grup.json'; let db = fs.existsSync(D) ? JSON.parse(fs.readFileSync(D)) : { mute: {}, jadwal: {} };
function sv() { fs.writeFileSync(D, JSON.stringify(db, null, 2)); }

function run(b, a) { return new Promise((r, j) => execFile(b, a, { maxBuffer: 1024 * 1024 * 50 }, (e, o, s) => { if (e) { e.stderr = s; j(e); } else r({ stdout: o, stderr: s }); })); }
async function d(m, t) { let b = Buffer.from([]); for await (const c of await downloadContentFromMessage(m, t)) b = Buffer.concat([b, c]); return b; }

async function mkSticker(p, a, wm = '') {
    let o = path.join(path.dirname(p), `stk_${cr.randomUUID()}.webp`);
    let s = 'scale=512:512:force_original_aspect_ratio=decrease,fps=15,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000,setsar=1';
    if (wm) s += `,drawtext=text='${wm}':fontcolor=white:fontsize=20:x=10:y=10`;
    let args = a ? ['-y','-i',p,'-vf',s,'-t','8','-loop','0','-an','-vsync','0','-vcodec','libwebp','-q:v','55','-preset','default','-fs','0.9M',o] : ['-y','-i',p,'-vf',s,'-vcodec','libwebp','-lossless','0','-q:v','75','-preset','picture','-loop','0','-an','-vsync','0',o];
    await run('ffmpeg', args); return o;
}

const E = {
    alyaai:{p:'/api/ai/alya',q:'message'}, jokowi:{p:'/api/ai/jokowi',q:'message'}, gpt5:{p:'/api/ai/gpt5',q:'text'}, gptanon:{p:'/api/ai/gptanon',q:'text'}, copilotai:{p:'/api/ai/copilot-think',q:'text'}, msai:{p:'/api/ai/microsoft',q:'text'}, glmai:{p:'/api/ai/glm',q:'text'}, aiunlimited:{p:'/api/ai/unlimited',q:'text'}, googleai:{p:'/api/ai/google',q:'text'}, qwenai:{p:'/api/ai/qwen',q:'text'}, deepseekai:{p:'/api/ai/deepseek',q:'text'}, cici:{p:'/api/ai/cici',q:'text'}, geminiapi:{p:'/api/ai/gemini',q:'text'}, geminilite:{p:'/api/ai/gemini-lite',q:'text'}, vanice:{p:'/api/ai/vanice',q:'text'},
    ttsdracin:{p:'/api/audio/tts-id',q:'text'},
    tiktokdl:{p:'/api/download/tiktok',q:'url'}, ytmp3:{p:'/api/download/ytmp3',q:'url'}, ytmp4:{p:'/api/downloader/ytmp4',q:'url'}, igdl:{p:'/api/downloader/Instagram',q:'url'}, spotifydl:{p:'/api/downloader/spotify',q:'url'}, pinterest:{p:'/api/downloader/pinterest',q:'url'},
    animehot:{p:'/api/image/anime-hot',q:'text'}, bluearchive:{p:'/api/image/bluearchive',q:'text'}, nanobanana:{p:'/api/img/nanobanana',q:'text'}, qween:{p:'/api/img/qween',q:'text'}, kyysgpt:{p:'/api/ai/image/KyysGPT',q:'text'}, imgtoreal:{p:'/api/img/toreal',q:'image'},
    bratgen:{p:'/api/maker/brat',q:'text'}, bratvid:{p:'/api/maker/bratvid',q:'text'}, bratvermail:{p:'/api/maker/brat-vermail',q:'text'}, bratvidvermeil:{p:'/api/maker/bratvid-vermeil',q:'text'},
    iqcip:{p:'/api/canvas/iqc-pink',q:'text'}, iqcpink:{p:'/api/canvas/iqc-pink',q:'text'}, pakustadz:{p:'/api/canvas/pak-ustadz',q:'text'}, ffgirl:{p:'/api/canvas/ffgirl',q:'username'}, fakedana:{p:'/api/canvas/fake-dana',q:'saldo'}, fakeff:{p:'/api/canvas/fake-ff',q:'username'}, balogo:{p:'/api/maker/balogo',q:'text'}, carbon:{p:'/api/canvas/carbon',q:'text'}, codesnap:{p:'/api/image/codesnap',q:'text'}, quoteimg:{p:'/api/image/quoteimg',q:'text'},
    memedrake:{p:'/api/meme/meme-drake',q:'teks1'}, jarvis:{p:'/api/meme/jarvis',q:'text'},
    tebaklagu:{p:'/api/game/tebak-lagu',q:'text'}, tebakgambar:{p:'/api/game/tebak-gambar',q:'text'},
    stikerpack:{p:'/api/search/sticker-pack',q:'q'}, ytsearch:{p:'/api/search/youtube',q:'q'}, spotifysearch:{p:'/api/search/spotify',q:'q'}, githubsearch:{p:'/api/search/github',q:'q'}, animesearch:{p:'/api/search/anime',q:'q'}, pinterestv2:{p:'/api/search/pinterest-v2',q:'q'}, memesearch:{p:'/api/search/meme-search',q:'q'},
    zodiak:{p:'/api/primbon/zodiak',q:'tanggal'}, artinama:{p:'/api/primbon/artinama',q:'nama'},
    amprem:{p:'/api/premium/amprem',q:'email'},
    sholawat:{p:'/api/random/tobrut',q:'text'}, ttgirl:{p:'/api/asupan/tiktokgirl',q:'text'}, cecanchina:{p:'/api/cecan/China',q:'text'}, cecanindo:{p:'/api/cecan/Indonesia',q:'text'}, cecanjepang:{p:'/api/cecan/Japan',q:'text'}, randquote:{p:'/api/random/quotes',q:'text'}, lahelu:{p:'/api/random/lahelu',q:'text'}, tobrut:{p:'/api/random/tobrut',q:'text'}, andin:{p:'/api/random/andin',q:'text'},
    asupannot:{p:'/api/asupan/notnot',q:'text'}, asupankayes:{p:'/api/asupan/kayes',q:'text'}, asupangheayubi:{p:'/api/asupan/gheayubi',q:'text'}, asupanbocil:{p:'/api/asupan/bocil',q:'text'},
    tempmailcreate:{p:'/api/tools/temp-mail/create',q:'text'}, tempmailinbox:{p:'/api/tools/temp-mail/inbox',q:'email'},
    stalktiktok:{p:'/api/stalker/tiktok',q:'username'}, stalkig:{p:'/api/stalker/ig',q:'username'},
    cecanjni:{p:'/api/cecan/Jeni',q:'text'}, cecanhijab:{p:'/api/cecan/Hijaber',q:'text'}, asupansantuy:{p:'/api/asupan/santuy',q:'text'}, asupanpanrika:{p:'/api/asupan/panrika',q:'text'},
    cecantahi:{p:'/api/cecan/Thailand',q:'text'}, cecanvietn:{p:'/api/cecan/Vietnam',q:'text'}, ccanjiso:{p:'/api/cecan/Jiso',q:'text'}, ccanryuj:{p:'/api/cecan/Ryujin',q:'text'}, cecanjutn:{p:'/api/cecan/Justinaxie',q:'text'},
    hentailist: { p: '/api/anime-hen/nekopoi/hentai-list', q: 'text' }, nepsearch: { p: '/api/anime-hen/nekopoi/search', q: 'query' }, nepcategory: { p: '/api/anime-hen/nekopoi/category', q: 'category' },
    nepdetail: { p: '/api/anime-hen/nekopoi/detail', q: 'url' }, dl: { p: '/api/anime-hen/nekopoi/detail', q: 'url' }
};

async function cp(p, q={}) {
    let r = await axios.get(U+p, { params: { ...q, apikey: K }, responseType: 'arraybuffer', timeout: 15000 });
    let h = r.headers['content-type']||'';
    if (h.startsWith('application/json')) return JSON.parse(r.data.toString());
    if (h.startsWith('image/')||h.startsWith('video/')||h.startsWith('audio/')) return { _m: true, b: Buffer.from(r.data), h };
    return r.data.toString();
}

function gM() { const d = C.IMG; if (!fs.existsSync(d)) return null; const f = fs.readdirSync(d); for (let n of f) { if (n.endsWith('.mp4')) return { p: path.join(d, n), t: 'mp4' }; if (n.endsWith('.gif')) return { p: path.join(d, n), t: 'gif' }; } return null; }

function formatTextResponse(data, cmd) {
    if (cmd === 'stalktiktok' && data?.result) { const d = data.result; return `STALK TIKTOK\n───────────────\nNama: ${d.nickname || '-'} (@${d.username || '-'})\nUser ID: ${d.userId || d.userid || '-'}\nVerifikasi: ${d.verified ? 'Ya' : 'Tidak'}\nAkun Private: ${d.privateAccount ? 'Ya' : 'Tidak'}\nBergabung: ${d.createdAt ? new Date(d.createdAt).toLocaleDateString('id-ID') : '-'}\nBio: ${d.signature || d.bio || '-'}\nFollowers: ${d.followerCount || d.followers || '-'}\nFollowing: ${d.followingCount || d.following || '-'}\nTotal Likes: ${d.heartCount || d.likes || '-'}`; }
    if (cmd === 'stalkig' && data?.result) { const d = data.result; return `STALK INSTAGRAM\n───────────────\nNama: ${d.full_name || '-'} (@${d.username || '-'})\nPost: ${d.media_count || d.posts || '-'}\nFollowers: ${d.follower_count || d.followers || '-'}\nFollowing: ${d.following_count || d.following || '-'}\nBio: ${d.biography || d.bio || '-'}\nAkun Private: ${d.is_private ? 'Ya' : 'Tidak'}\nVerified: ${d.is_verified ? 'Ya' : 'Tidak'}`; }
    if (cmd === 'artinama' && data?.result) return `ARTI NAMA\n───────────────\nNama: ${data.result.nama || data.nama || '-'}\nArti: ${data.result.arti || data.arti || '-'}`;
    if (cmd === 'zodiak' && data?.result) { const d = data.result; return `RAMALAN ZODIAK\n───────────────\nZodiak: ${d.zodiak || d.nama || '-'}\nRamalan: ${d.ramalan || d.deskripsi || '-'}`; }
    if (cmd === 'jokowi' && data?.message) return data.message;
    if (cmd === 'jokowi' && data?.text) return data.text;
    if (cmd === 'jokowi' && data?.result) return typeof data.result === 'string' ? data.result : JSON.stringify(data.result);
    if (['ytsearch', 'spotifysearch', 'githubsearch', 'animesearch', 'memesearch', 'pinterestv2', 'stikerpack'].includes(cmd)) {
        let items = []; if (Array.isArray(data)) items = data; else if (data?.result && Array.isArray(data.result)) items = data.result; else if (data?.items && Array.isArray(data.items)) items = data.items; else if (data?.data && Array.isArray(data.data)) items = data.data;
        if (!items.length) return '❌ Tidak ada hasil ditemukan.';
        let label = cmd.toUpperCase().replace('SEARCH', '').replace('V2', ''); let out = `📌 *${label} SEARCH*\n───────────────\n`;
        items.slice(0, 5).forEach((item, i) => {
            const title = item.title || item.name || item.judul || `Item ${i+1}`;
            const link = item.url || item.link || item.permalink || '#';
            const dur = item.duration ? ` (${Math.floor(item.duration/60)}:${String(Math.floor(item.duration%60)).padStart(2,'0')})` : '';
            out += `\n${i+1}. ${title}${dur}\n   ${link}`;
        });
        return out + '\n\n_Ketik .' + cmd + ' <kata> untuk mencari lagi._';
    }
    if (data?.message) return data.message; if (data?.text) return data.text; if (typeof data === 'string') return data; if (data?.result && typeof data.result === 'string') return data.result; return null;
}

// ================= SPREM (port setia dari sprem.js) =================
function buildStickerExif(metadata) {
    const json = Buffer.from(JSON.stringify(metadata), 'utf-8');
    const exif = Buffer.concat([
        Buffer.from([
            0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57,
            0x07, 0x00,
        ]),
        Buffer.alloc(4),
        Buffer.from([0x16, 0x00, 0x00, 0x00]),
        json,
    ]);
    exif.writeUInt32LE(json.length, 14);
    return exif;
}

function makeChunk(type, data) {
    const typeBuffer = Buffer.from(type);
    const sizeBuffer = Buffer.alloc(4);
    sizeBuffer.writeUInt32LE(data.length, 0);
    const padding = data.length % 2 === 1 ? Buffer.from([0x00]) : Buffer.alloc(0);
    return Buffer.concat([typeBuffer, sizeBuffer, data, padding]);
}

function setWebpExif(webpBuffer, metadata) {
    if (
        webpBuffer.slice(0, 4).toString() !== 'RIFF' ||
        webpBuffer.slice(8, 12).toString() !== 'WEBP'
    ) {
        throw new Error('File bukan WEBP valid.');
    }

    const chunks = [];
    let offset = 12;

    while (offset + 8 <= webpBuffer.length) {
        const type = webpBuffer.slice(offset, offset + 4).toString();
        const size = webpBuffer.readUInt32LE(offset + 4);
        const chunkStart = offset;
        const chunkEnd = offset + 8 + size + (size % 2);

        if (chunkEnd > webpBuffer.length) break;

        if (type !== 'EXIF') {
            chunks.push(webpBuffer.slice(chunkStart, chunkEnd));
        }

        offset = chunkEnd;
    }

    const exifPayload = buildStickerExif(metadata);
    const exifChunk = makeChunk('EXIF', exifPayload);
    const body = Buffer.concat([...chunks, exifChunk]);

    const header = Buffer.alloc(12);
    header.write('RIFF', 0);
    header.writeUInt32LE(body.length + 4, 4);
    header.write('WEBP', 8);

    return Buffer.concat([header, body]);
}

// Metadata PERSIS seperti sprem.js
const SPREM_META = {
    'sticker-pack-id': '2be7e369-b5ce-4706-a3d4-f78805a20328',
    'sticker-pack-name': 'OMAK',
    'sticker-pack-publisher': 'HAI',
    'accessibility-text': 'MR ALOC',
    'android-app-store-link': 'https://whatsapp.com',
    'ios-app-store-link': 'https://whatsapp.com/ios',
    emojis: ['🦸', '😴', '😌'],
    'is-from-sticker-maker': 0,
    'is-avatar-sticker': 0,
    'avatar-sticker-template-id': 'whatsapp',
    'is-ai-sticker': 0,
    'is-avatar-country-sticker': 1,
    'is-avatar-instant-sticker': 1,
    'sticker-maker-source-type': 4,
    'is-avatar-social-sticker': 1,
    'avatar-sticker-style': 'whatsapp',
    'avatar-sticker-revision-id': '2026',
    'is-from-user-created-pack': 1,
    'origin-pack-id': 'whatsapp',
    'is-text-sticker': 1,
    premium: 1,
};

async function downloadStickerBuffer(stickerMessage) {
    const stream = await downloadContentFromMessage(stickerMessage, 'sticker');
    const chunks = [];
    for await (const chunk of stream) chunks.push(chunk);
    return Buffer.concat(chunks);
}

/** Alur kirim PERSIS seperti sprem.js (prepareWAMessageMedia + relayMessage) */
async function sendSpremLikeOriginal(sock, jid, msg, stickerMessage) {
    const stickerBuffer = await downloadStickerBuffer(stickerMessage);
    const finalStickerBuffer = setWebpExif(stickerBuffer, SPREM_META);

    const media = await prepareWAMessageMedia(
        { sticker: finalStickerBuffer },
        { upload: sock.waUploadToServer }
    );

    const msgContent = {
        messageContextInfo: {
            limitSharingV2: {
                sharingLimited: true,
                trigger: 'CHAT_SETTING',
                limitSharingSettingTimestamp: Date.now().toString(),
                initiatedByMe: true,
            },
        },
        stickerMessage: {
            ...media.stickerMessage,
            isAnimated: stickerMessage.isAnimated || false,
            isAvatar: true,
            isAiSticker: true,
            isLottie: false,
        },
    };

    const built = await generateWAMessageFromContent(jid, msgContent, {
        quoted: msg,
        userJid: sock.user?.id,
    });

    await sock.relayMessage(jid, built.message, {
        messageId: built.key.id,
    });
}
// ================================================================

// ================= NEP PENDING (pilih episode / kualitas) =================
const nepPending = {}; // key: id user → { type, data, expires }
function nepSet(id, type, data) {
    nepPending[id] = { type, data, expires: Date.now() + 5 * 60 * 1000 };
}
function nepGet(id) {
    const p = nepPending[id];
    if (!p) return null;
    if (Date.now() > p.expires) { delete nepPending[id]; return null; }
    return p;
}
function nepClear(id) { delete nepPending[id]; }

async function sendNepDetail(sock, f, msg, res, id, re) {
    let text = `🎬 *${res.title || 'Detail'}*\n───────────────\n`;
    if (res.type) text += `Tipe: ${res.type}\n`;
    if (res.synopsis) {
        let syn = String(res.synopsis);
        text += `\n📝 ${syn.slice(0, 350)}${syn.length > 350 ? '...' : ''}\n`;
    }
    if (res.info && typeof res.info === 'object') {
        for (let [k, v] of Object.entries(res.info)) {
            if (v) text += `\n• ${k}: ${v}`;
        }
    }

    // Series → pilih episode atau FULL
    if (Array.isArray(res.episodes) && res.episodes.length) {
        text += `\n\n📺 *Pilih:*\n0. 📦 FULL (semua episode)\n`;
        res.episodes.slice(0, 25).forEach((ep, i) => {
            text += `\n${i + 1}. ${ep.title || 'Episode'}`;
        });
        text += `\n\n⏳ Balas *angka* (0 = full, 1 = ep1, dst) dalam 5 menit.\n_via ${C.WM}_`;
        nepSet(id, 'episodes', { episodes: res.episodes, image: res.image, title: res.title });
        if (res.image) {
            try { await sock.sendMessage(f, { image: { url: res.image }, caption: text }, { quoted: msg }); }
            catch { await re(text); }
        } else {
            await re(text);
        }
        return;
    }

    // Episode → streams + pilih kualitas
    if (Array.isArray(res.streams) && res.streams.length) {
        text += `\n\n▶️ *Stream:*\n`;
        res.streams.forEach((s, i) => { text += `${i + 1}. ${s}\n`; });
    }
    if (Array.isArray(res.downloads) && res.downloads.length) {
        text += `\n⬇️ *Pilih Kualitas (balas angka):*\n`;
        res.downloads.forEach((dl, i) => {
            text += `\n${i + 1}. ${dl.title || 'Link'}`;
        });
        text += `\n\n⏳ Balas *angka* untuk link download.\n⚠️ Auto-kirim video hanya jika ada direct MP4 (API biasanya lewat ouo.io).\n_via ${C.WM}_`;
        nepSet(id, 'quality', { downloads: res.downloads, image: res.image, streams: res.streams || [], title: res.title });
    } else {
        text += `\n_via ${C.WM}_`;
    }

    if (res.image) {
        try { await sock.sendMessage(f, { image: { url: res.image }, caption: text }, { quoted: msg }); }
        catch { await re(text); }
    } else {
        await re(text);
    }
}
// ==========================================================================

setInterval(() => { let n = new Date(); let t = `${String(n.getHours()).padStart(2,'0')}:${String(n.getMinutes()).padStart(2,'0')}`; for (let g in db.jadwal) { if (db.jadwal[g] === t) console.log(`⏰ Waktu ${t} tercapai untuk grup ${g}.`); } }, 60000);

async function start() {
  const { state, saveCreds } = await useMultiFileAuthState(C.AUTH);
  const { version } = await fetchLatestBaileysVersion();

  const sock = s({
    version,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, lg)
    },
    logger: lg,
    browser: Browsers.ubuntu('Chrome'),
    printQRInTerminal: false,
    syncFullHistory: false,
    markOnlineOnConnect: false,
    generateHighQualityLinkPreview: false,
    connectTimeoutMs: 30000,
    defaultQueryTimeoutMs: 30000,
    keepAliveIntervalMs: 15000,
    emitOwnEvents: false,
    fireInitQueries: false,
    retryRequestDelayMs: 300,
    maxMsgRetryCount: 2
  });

  let pairingRequested = false;

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', async (u) => {
    const { connection, lastDisconnect, qr } = u;

    // Minta pairing code setelah socket siap (bukan langsung)
    if (!sock.authState.creds.registered && !pairingRequested && (connection === 'connecting' || connection === undefined)) {
      pairingRequested = true;
      try {
        let n = (C.PAIRING || '').replace(/[^0-9]/g, '');
        if (!n) {
          const i = rl.createInterface({ input: process.stdin, output: process.stdout });
          n = await new Promise(r => i.question('📱 No WA (62xxx): ', a => { i.close(); r(a.trim()); }));
          n = n.replace(/[^0-9]/g, '');
        }
        if (!n) {
          console.error('❌ Nomor pairing kosong. Set C.PAIRING di config.');
          return;
        }

        // Tunggu singkat biar socket stabil
        await new Promise(r => setTimeout(r, 1500));

        let code = null;
        // Coba custom code dulu (harus 8 karakter A-Z0-9)
        if (C.CODE && /^[A-Z0-9]{8}$/i.test(C.CODE)) {
          try {
            code = await sock.requestPairingCode(n, C.CODE.toUpperCase());
            console.log('🔑 Kode pairing (custom):', code);
          } catch (e) {
            console.warn('⚠️ Custom code ditolak:', e.message);
          }
        }
        if (!code) {
          try {
            code = await sock.requestPairingCode(n);
            console.log('🔑 Kode pairing:', code);
          } catch (e) {
            console.error('❌ Gagal request pairing:', e.message);
            pairingRequested = false;
            return;
          }
        }
        console.log('   ➜ Buka WA HP → Perangkat Tertaut → Tautkan dengan nomor telepon');
        console.log('   ➜ Masukkan kode di atas (biasanya muncul dengan tanda -)');
        console.log('   ➜ Jangan tutup terminal sampai status "open"');
      } catch (e) {
        console.error('❌ Pairing error:', e.message);
        pairingRequested = false;
      }
    }

    if (connection === 'open') {
      console.log(ASCII);
    }

    if (connection === 'close') {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      const shouldReconnect = statusCode !== 401 && statusCode !== 403;
      console.log('⚠️ Koneksi putus. code=', statusCode, 'reconnect=', shouldReconnect);
      if (shouldReconnect) {
        // delay singkat lalu restart
        setTimeout(() => start().catch(e => console.error('Reconnect fatal:', e)), 2000);
      } else {
        console.log('❌ Session invalid (logout). Hapus folder auth_info lalu jalankan ulang.');
      }
    }
  });

  (async () => { let now = new Date(); let tNow = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`; for (let g in db.jadwal) { let j = db.jadwal[g]; if (j && j === tNow) { let [aksi, waktu] = j.split(':'); if (aksi === 'close') await sock.groupSettingUpdate(g, 'announcement'); else if (aksi === 'open') await sock.groupSettingUpdate(g, 'not_announcement'); console.log(`⏰ Jadwal ${aksi} untuk ${g} dijalankan.`); delete db.jadwal[g]; sv(); } } })();

  sock.ev.on('messages.upsert', async (m) => {
    let msg = m.messages[0]; if (!msg.message) return;
    let f = msg.key.remoteJid; let isG = f.endsWith('@g.us'); let id = msg.key.participant || f; 
    let bdy = msg.message.conversation || msg.message.extendedTextMessage?.text || msg.message.imageMessage?.caption || msg.message.videoMessage?.caption || '';
    
    if (isG && db.mute[f] && db.mute[f].includes(id)) { await sock.sendMessage(f, { delete: msg.key }); return; }

    // === Handle balasan angka untuk pilih episode / kualitas ===
    let bare = bdy.trim();
    if (/^\d+$/.test(bare)) {
        let pend = nepGet(id);
        if (pend) {
            let num = parseInt(bare, 10);
            let reN = async (t) => { try { await sock.sendMessage(f, { text: t }, { quoted: msg }); } catch(e){} };
            try {
                if (pend.type === 'episodes') {
                    let eps = pend.data.episodes || [];
                    // 0 = FULL semua episode
                    if (num === 0) {
                        nepClear(id);
                        await reN(`⏳ Ambil link SEMUA episode (${eps.length})...`);
                        let fullText = `📦 *FULL* ${pend.data.title || ''}\nTotal: ${eps.length} episode\n───────────────\n`;
                        for (let i = 0; i < Math.min(eps.length, 15); i++) {
                            try {
                                let det = await cp('/api/anime-hen/nekopoi/detail', { url: eps[i].url });
                                let res = det?.result || {};
                                fullText += `\n*${i + 1}. ${eps[i].title || res.title || 'Ep'}*\n`;
                                if (res.streams && res.streams[0]) fullText += `▶️ ${res.streams[0]}\n`;
                                if (res.downloads && res.downloads[0] && res.downloads[0].links) {
                                    let lk = res.downloads[0].links[0];
                                    if (lk) fullText += `⬇️ ${lk.name}: ${lk.url}\n`;
                                }
                            } catch {
                                fullText += `\n*${i + 1}. ${eps[i].title}*\n   ${eps[i].url}\n`;
                            }
                        }
                        if (eps.length > 15) fullText += `\n... +${eps.length - 15} episode lain. Gunakan .dl <url ep> satu per satu.`;
                        fullText += `\n\n_via ${C.WM}_`;
                        await reN(fullText);
                        return;
                    }
                    if (num < 1 || num > eps.length) {
                        await reN(`❌ Pilih 0 (full) atau 1-${eps.length}`);
                        return;
                    }
                    let ep = eps[num - 1];
                    nepClear(id);
                    await reN(`⏳ Ambil detail episode ${num}...`);
                    let det = await cp('/api/anime-hen/nekopoi/detail', { url: ep.url });
                    let res = det?.result || det;
                    if (!res) { await reN('❌ Gagal ambil detail episode.'); return; }
                    await sendNepDetail(sock, f, msg, res, id, reN);
                    return;
                }
                if (pend.type === 'quality') {
                    let dls = pend.data.downloads || [];
                    if (num < 1 || num > dls.length) {
                        await reN(`❌ Pilih nomor 1-${dls.length}`);
                        return;
                    }
                    let chosen = dls[num - 1];
                    nepClear(id);
                    await reN(`⏳ Proses *${chosen.title || 'download'}*...`);

                    // Coba kirim video jika ada direct URL (jarang tersedia)
                    let sentVideo = false;
                    let links = chosen.links || [];
                    for (let l of links) {
                        let u = l.url || '';
                        if (/\.(mp4|mkv|webm)(\?|$)/i.test(u)) {
                            try {
                                await sock.sendMessage(f, { video: { url: u }, caption: `🎬 ${chosen.title || ''}\n_via ${C.WM}_` }, { quoted: msg });
                                sentVideo = true;
                                break;
                            } catch {}
                        }
                    }
                    if (sentVideo) return;

                    // Fallback: kirim semua mirror + stream
                    let text = `⬇️ *${chosen.title || 'Download'}*\n───────────────\n`;
                    links.forEach((l) => { text += `• ${l.name || 'Mirror'}: ${l.url}\n`; });
                    if (pend.data.streams && pend.data.streams.length) {
                        text += `\n▶️ Stream:\n`;
                        pend.data.streams.forEach((s, i) => { text += `${i + 1}. ${s}\n`; });
                    }
                    text += `\n⚠️ Link lewat shortener (ouo). Buka di browser.\nTidak bisa auto-kirim video karena server unduhan dilindungi.\n_via ${C.WM}_`;
                    if (pend.data.image) {
                        try { await sock.sendMessage(f, { image: { url: pend.data.image }, caption: text }, { quoted: msg }); }
                        catch { await reN(text); }
                    } else {
                        await reN(text);
                    }
                    return;
                }
            } catch (e) {
                await reN(`❌ ${e.message}`);
                return;
            }
        }
    }
    // ============================================================

    if (!bdy.trim() || !bdy.startsWith(C.PREFIX)) return;
    let [cmd, ...a] = bdy.slice(C.PREFIX.length).trim().split(/\s+/); let r = a.join(' ');
    let re = async (t) => { try { await sock.sendMessage(f, { text: t }, { quoted: msg }); } catch(e){} };

    if (cmd === 'id') return re(`🆔 JID: ${f}`);
    if (cmd === 'ipsaya') { try { let ip = await axios.get('https://api.ipify.org?format=json'); re(`🌐 IP Publik: ${ip.data.ip}`); } catch(e){ re('❌ Gagal ambil IP.'); } return; }

    if (cmd === 's') {
        let q = msg.message.extendedTextMessage?.contextInfo?.quotedMessage; let img = q?.imageMessage || msg.message.imageMessage; let vid = q?.videoMessage || msg.message.videoMessage;
        if (!img && !vid) return re('❌ Reply gambar/video dengan .s');
        await re('⏳ Bikin stiker...');
        let dir = path.join(__dirname, 'tmp'); if (!fs.existsSync(dir)) fs.mkdirSync(dir);
        let med = img || vid; let t = img ? 'image' : 'video';
        let buf = await d(med, t); let inp = path.join(dir, `in_${cr.randomUUID()}.${t==='image'?'jpg':'mp4'}`);
        await fsp.writeFile(inp, buf);
        try { let out = await mkSticker(inp, t==='video', C.WM); await sock.sendMessage(f, { sticker: { url: out } }, { quoted: msg }); }
        finally { await fsp.rm(dir, { recursive: true, force: true }); }
        return;
    }

    if (cmd === 'gif') {
        let q = msg.message.extendedTextMessage?.contextInfo?.quotedMessage; let vid = q?.videoMessage || msg.message.videoMessage;
        if (!vid) return re('❌ Reply video dengan .gif');
        await re('⏳ Ubah video ke GIF...');
        let dir = path.join(__dirname, 'tmp'); if (!fs.existsSync(dir)) fs.mkdirSync(dir);
        let buf = await d(vid, 'video'); let inp = path.join(dir, `in_${cr.randomUUID()}.mp4`);
        await fsp.writeFile(inp, buf);
        let out = path.join(dir, `out_${cr.randomUUID()}.gif`);
        try { await run('ffmpeg', ['-y', '-i', inp, '-vf', 'fps=10,scale=320:-1', '-t', '8', out]); await sock.sendMessage(f, { video: { url: out }, gifPlayback: true }, { quoted: msg }); }
        finally { await fsp.rm(dir, { recursive: true, force: true }); }
        return;
    }

    if (cmd === 'img') {
        if (!r) return re('❌ Contoh: .img menu.gif');
        let p = path.join(C.IMG, r); if (!fs.existsSync(p)) return re('❌ File tidak ditemukan di folder img.');
        let ext = path.extname(p).toLowerCase();
        if (ext === '.gif' || ext === '.mp4') await sock.sendMessage(f, { video: { url: p }, gifPlayback: true }, { quoted: msg });
        else if (['.jpg','.jpeg','.png','.webp'].includes(ext)) await sock.sendMessage(f, { image: { url: p } }, { quoted: msg });
        else re('❌ Format file tidak didukung.');
        return;
    }

    if (cmd === 'imgtoreal') {
        let q = msg.message.extendedTextMessage?.contextInfo?.quotedMessage; let img = q?.imageMessage || msg.message.imageMessage;
        if (!img) return re('❌ Reply gambar dengan .imgtoreal');
        await re('⏳ Memproses gambar dengan AI...');
        let buf = await d(img, 'image');
        try {
            const form = new FormData(); form.append('image', buf, 'image.jpg');
            const res = await axios.post(U + '/api/img/toreal', form, { headers: { ...form.getHeaders(), 'x-api-key': K }, responseType: 'arraybuffer', timeout: 30000 });
            const h = res.headers['content-type'] || '';
            if (h.startsWith('image/')) { await sock.sendMessage(f, { image: Buffer.from(res.data), caption: `_via ${C.WM}_` }, { quoted: msg }); }
            else { let txt = res.data.toString(); try { txt = JSON.parse(txt); txt = formatTextResponse(txt, cmd) || JSON.stringify(txt); } catch {} re(txt); }
        } catch (e) { re(`❌ ${e.response?.data?.message || e.message}`); }
        return;
    }

    if (cmd === 'menu') {
      let menu = `[ 𝟬𝘅𝗭𝗲𝗻𝗶𝘁𝗵-𝘯𝘦𝘸 𝘣𝘰𝘵  ]\n───────────────\n`;
      for (let [k, v] of Object.entries(E)) menu += `• .${k} <${v.q}>\n`;
      menu += `───────────────\nWM: ${C.WM}`;
      let img = gM(); if (img) { if (img.t === 'mp4') await sock.sendMessage(f, { video: { url: img.p }, gifPlayback: true, caption: menu }, { quoted: msg }); else await sock.sendMessage(f, { image: { url: img.p }, caption: menu }, { quoted: msg }); } else await re(menu);
      return;
    }

    // ================= SPREM COMMAND (port sprem.js) =================
    if (cmd === 'sprem') {
        // Ambil quoted message (sama seperti handler asli)
        const contextInfo =
            msg.message?.extendedTextMessage?.contextInfo || {};
        const quotedMessage = contextInfo.quotedMessage;
        let stk = quotedMessage?.stickerMessage;
        let img = quotedMessage?.imageMessage || msg.message.imageMessage;
        let vid = quotedMessage?.videoMessage || msg.message.videoMessage;

        try {
            // === Path utama: reply STIKER (persis sprem.js) ===
            if (stk) {
                if (stk.mimetype && stk.mimetype !== 'image/webp') {
                    return re('❌ Ini bukan sticker WEBP biasa. Untuk lottie beda cara.');
                }
                await re('⏳ Inject SPREM...');
                await sendSpremLikeOriginal(sock, f, msg, stk);
                return;
            }

            // === Tambahan: reply gambar/video → jadi stiker dulu, lalu inject sama ===
            if (img || vid) {
                await re('⏳ Buat stiker + inject SPREM...');
                let dir = path.join(__dirname, 'tmp');
                if (!fs.existsSync(dir)) fs.mkdirSync(dir);
                let med = img || vid;
                let t = img ? 'image' : 'video';
                let buf = await d(med, t);
                let inp = path.join(dir, `in_${cr.randomUUID()}.${t === 'image' ? 'jpg' : 'mp4'}`);
                await fsp.writeFile(inp, buf);
                try {
                    let out = await mkSticker(inp, t === 'video', '');
                    let webpBuf = await fsp.readFile(out);
                    // bangun objek mirip stickerMessage agar alur sama
                    const fakeStickerMessage = {
                        mimetype: 'image/webp',
                        isAnimated: t === 'video',
                        // downloadContentFromMessage butuh mediaKey dll —
                        // jadi di sini inject + kirim manual dengan alur yang sama
                    };
                    // Inject EXIF lalu kirim dengan prepareWAMessageMedia + relay (sama sprem.js)
                    const finalStickerBuffer = setWebpExif(webpBuf, SPREM_META);
                    const media = await prepareWAMessageMedia(
                        { sticker: finalStickerBuffer },
                        { upload: sock.waUploadToServer }
                    );
                    const msgContent = {
                        messageContextInfo: {
                            limitSharingV2: {
                                sharingLimited: true,
                                trigger: 'CHAT_SETTING',
                                limitSharingSettingTimestamp: Date.now().toString(),
                                initiatedByMe: true,
                            },
                        },
                        stickerMessage: {
                            ...media.stickerMessage,
                            isAnimated: t === 'video',
                            isAvatar: true,
                            isAiSticker: true,
                            isLottie: false,
                        },
                    };
                    const built = generateWAMessageFromContent(f, msgContent, {
                        quoted: msg,
                        userJid: sock.user.id,
                    });
                    await sock.relayMessage(f, built.message, { messageId: built.key.id });
                } finally {
                    await fsp.rm(dir, { recursive: true, force: true }).catch(() => {});
                }
                return;
            }

            return re('❌ Reply sticker WEBP biasa dulu.');
        } catch (e) {
            console.error('[SPREM]', e);
            return re(`❌ Gagal inject atribut sticker: ${e.message}`);
        }
    }
    // ============================================================

    // ================= GRUP (ADMIN FIX) =================
    if (isG) {
        let gm = await sock.groupMetadata(f).catch(() => null);
        if (!gm) return re('❌ Gagal mengambil data grup.');
        let adm = gm.participants.find(p=>p.id===id)?.admin;
        let knownAdmins = ['6283822259027@s.whatsapp.net', '278567871062047@lid', '27475593683079@lid'];
        let bAdm = knownAdmins.some(a => gm.participants.find(p=>p.id===a)?.admin);
        if (!adm && !C.OWNER.some(o=>id.includes(o))) return re('❌ Perintah grup khusus admin!');
        if (!bAdm) return re('❌ Bot harus admin grup!');
        let mJ = msg.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
        if (cmd === 'kick') { let j = mJ[0] || msg.message.extendedTextMessage?.contextInfo?.participant; if (!j) return re('❌ Tag user!'); await sock.groupParticipantsUpdate(f, [j], 'remove'); re('✅ Berhasil kick.'); return; }
        if (cmd === 'add') { let n = r.replace(/[^0-9]/g,''); if (!n) return re('❌ Contoh: .add 628xxx'); await sock.groupParticipantsUpdate(f, [`${n}@s.whatsapp.net`], 'add'); re('✅ Berhasil add.'); return; }
        if (cmd === 'close') { await sock.groupSettingUpdate(f, 'announcement'); re('🔒 Grup ditutup (hanya admin).'); return; }
        if (cmd === 'open') { await sock.groupSettingUpdate(f, 'not_announcement'); re('🔓 Grup dibuka.'); return; }
        if (cmd === 'mute') { let j = mJ[0]; if (!j) return re('❌ Tag user!'); if (!db.mute[f]) db.mute[f]=[]; if (!db.mute[f].includes(j)) { db.mute[f].push(j); sv(); } re(`✅ ${j} di-mute.`); return; }
        if (cmd === 'unmute') { let j = mJ[0]; if (!j) return re('❌ Tag user!'); if (db.mute[f]) { db.mute[f] = db.mute[f].filter(x=>x!==j); sv(); } re(`✅ ${j} di-unmute.`); return; }
        if (cmd === 'setopen' || cmd === 'setclose') {
            let t = r.trim(); if (!t || !t.match(/^\d{2}:\d{2}$/)) return re('❌ Format waktu: HH:MM (contoh 10:00)');
            db.jadwal[f] = `${cmd === 'setclose' ? 'close' : 'open'}:${t}`; sv(); re(`✅ Jadwal ${cmd} di grup ini diset ke ${t}.`);
            return;
        }
    }

    // ================= KYZZ API =================
    let ep = E[cmd]; if (!ep) return re('❌ Perintah tidak dikenal. Ketik .menu');
    await re('⏳ Proses...');
    let p = { [ep.q]: r };
    if (cmd === 'pakustadz' && r.includes('--kata')) { let s = r.split('--kata'); p.text = s[0].trim(); p.kata = s[1].trim()||'judul'; }
    if (cmd === 'memedrake' && r.includes('--teks2')) { let s = r.split('--teks2'); p.teks1 = s[0].trim(); p.teks2 = s[1].trim()||'lu'; }
    if (cmd === 'ttsdracin' && r.includes('--voice')) { let s = r.split('--voice'); p.text = s[0].trim(); p.voice = s[1].trim()||'laki'; }
    if (cmd === 'bratgen' && r.includes('--theme')) { let s = r.split('--theme'); p.text = s[0].trim(); p.theme = s[1].trim()||'white'; }
    if (cmd === 'bratvid' && r.includes('--theme')) { let s = r.split('--theme'); p.text = s[0].trim(); p.theme = s[1].trim()||'white'; p.format = 'mp4'; }
    if (cmd === 'iqcip' && r.includes('--time')) { let s = r.split('--time'); p.text = s[0].trim(); p.time = s[1].trim()||'22:09'; }
    if (cmd === 'tempmailinbox' && r.includes('--token')) { let s = r.split('--token'); p.email = s[0].trim(); p.token = s[1].trim()||''; }
    if (cmd === 'ffgirl' && r.includes('--template')) { let s = r.split('--template'); p.username = s[0].trim(); p.template = s[1].trim()||'random'; }

    try {
      let d = await cp(ep.p, p);
        // === HENTAILIST / SEARCH / CATEGORY → teks saja ===
    if (['hentailist', 'nepsearch', 'nepcategory'].includes(cmd)) {
        let items = [];
        if (Array.isArray(d?.result)) items = d.result;
        else if (Array.isArray(d?.items)) items = d.items;
        else if (Array.isArray(d)) items = d;
        else if (d?.result && typeof d.result === 'object') items = [d.result];

        if (!items.length) {
            await re('❌ Tidak ada hasil ditemukan.');
            return;
        }

        let total = d?.total || items.length;
        let text = `📋 *${cmd.toUpperCase()}*\nTotal: ${total}\n───────────────\n`;
        items.slice(0, 15).forEach((item, i) => {
            const title = item.title || item.name || 'Tanpa judul';
            const link = item.url || item.link || item.permalink || '';
            text += `\n${i + 1}. ${title}`;
            if (link) text += `\n   ${link}`;
        });
        if (items.length > 15) text += `\n\n... dan ${items.length - 15} lainnya.`;
        text += `\n\n💡 Ketik *.dl <url>* untuk detail + pilih episode.\n_via ${C.WM}_`;
        await re(text);
        return;
    }

    // === .dl / .nepdetail ===
    if (['dl', 'nepdetail'].includes(cmd)) {
        if (!r || !r.includes('http')) {
            await re('❌ Contoh: .dl https://nekopoi.care/hentai/...');
            return;
        }
        let res = d?.result || d;
        if (!res || typeof res !== 'object') {
            await re('❌ Gagal mengambil detail. Pastikan link valid.');
            return;
        }
        await sendNepDetail(sock, f, msg, res, id, re);
        return;
    }

      if (d && d._m) {
        if (d.h.startsWith('image/')) await sock.sendMessage(f, { image: d.b, caption: `_via ${C.WM}_` }, { quoted: msg });
        else if (d.h.startsWith('video/')) await sock.sendMessage(f, { video: d.b, caption: `_via ${C.WM}_` }, { quoted: msg });
        else if (d.h.startsWith('audio/')) await sock.sendMessage(f, { audio: d.b, mimetype: d.h }, { quoted: msg });
        return;
      }
      let mediaUrl = null;
      if (d?.result) { mediaUrl = d.result.play || d.result.wmplay || d.result.hdplay || d.result.music || d.result.audio || d.result.video || d.result.url || d.result.file; }
      if (!mediaUrl) mediaUrl = d?.url || d?.image || d?.audio || d?.video;

      if (mediaUrl) {
          if (['tiktokdl', 'ytmp4', 'igdl', 'pinterest'].includes(cmd)) {
              try { await sock.sendMessage(f, { video: { url: mediaUrl }, caption: `_via ${C.WM}_` }, { quoted: msg }); return; } catch {}
              try { await sock.sendMessage(f, { audio: { url: mediaUrl }, mimetype: 'audio/mpeg' }, { quoted: msg }); return; } catch {}
              try { await sock.sendMessage(f, { image: { url: mediaUrl }, caption: `_via ${C.WM}_` }, { quoted: msg }); return; } catch {}
              await re('❌ Gagal memuat media. Coba link lain.'); return;
          }
          if (['ytmp3', 'spotifydl', 'spotifysearch'].includes(cmd)) {
              try { await sock.sendMessage(f, { audio: { url: mediaUrl }, mimetype: 'audio/mpeg' }, { quoted: msg }); return; } catch {}
              try { await sock.sendMessage(f, { video: { url: mediaUrl }, caption: `_via ${C.WM}_` }, { quoted: msg }); return; } catch {}
              try { await sock.sendMessage(f, { image: { url: mediaUrl }, caption: `_via ${C.WM}_` }, { quoted: msg }); return; } catch {}
              await re('❌ Gagal memuat audio. Coba link lain.'); return;
          }
          try {
              await sock.sendMessage(f, { image: { url: mediaUrl }, caption: `_via ${C.WM}_` }, { quoted: msg });
          } catch {
              try { await sock.sendMessage(f, { video: { url: mediaUrl }, caption: `_via ${C.WM}_` }, { quoted: msg }); } catch {
                  try { await sock.sendMessage(f, { audio: { url: mediaUrl }, mimetype: 'audio/mpeg' }, { quoted: msg }); } catch {
                      await re('❌ Link media ditemukan, tetapi gagal dikirim.');
                      return;
                  }
              }
          }
          return;
      }

      let av = d?.result?.avatar?.thumb || d?.result?.profile_pic_url_hd;
      if (av) { let cap = formatTextResponse(d, cmd); if (cap) await sock.sendMessage(f, { image: { url: av }, caption: cap }, { quoted: msg }); else await sock.sendMessage(f, { image: { url: av }, caption: `_via ${C.WM}_` }, { quoted: msg }); return; }
      let t = formatTextResponse(d, cmd);
      if (t) return re(t);
      await re('```json\n' + JSON.stringify(d, null, 2).slice(0, 3000) + '\n```');
    } catch(e) { await re(`❌ ${e.response?.data?.message || e.message}`); }
  });
  return sock;
}
start().catch(e=>{ console.error('Fatal:', e); process.exit(1); });
