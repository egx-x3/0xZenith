const a = require('axios');
const U = 'https://api.kyzzz.xyz', K = 'kyzz592116496';
async function c(p, q={}) { let r = await a.get(U+p, { params: { ...q, apikey: K }, timeout: 15000 }); return r.data; }
const e = {
  alyaai: { p: 'message', path: '/api/ai/alya' },
  ttsdracin: { p: 'text', path: '/api/audio/tts-id' },
  tiktokdl: { p: 'url', path: '/api/download/tiktok' },
  animehot: { p: 'text', path: '/api/image/anime-hot' },
  bratgen: { p: 'text', path: '/api/maker/brat' },
  iqcip: { p: 'text', path: '/api/canvas/iqc-pink' },
  stikerpack: { p: 'q', path: '/api/search/sticker-pack' },
  sholawat: { p: 'text', path: '/api/random/tobrut' },
  ttgirl: { p: 'text', path: '/api/asupan/tiktokgirl' },
  cecanchina: { p: 'text', path: '/api/cecan/China' },
  cecanindo: { p: 'text', path: '/api/cecan/Indonesia' },
  cecanjepang: { p: 'text', path: '/api/cecan/Japan' }
};
module.exports = { e, c };
